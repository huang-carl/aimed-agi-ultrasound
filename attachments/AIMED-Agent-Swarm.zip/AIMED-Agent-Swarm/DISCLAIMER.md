# 医疗免责声明 / Medical Disclaimer

**版本**: v1.0  
**生效日期**: 2026-05-02  
**适用项目**: AIMED Agent Swarm / 充盈视界 FillingVision

---

## 中文版本

### ⚠️ 重要声明

本项目（AIMED Agent Swarm / 充盈视界 FillingVision）**仅用于医疗 AI 科研学术研究**，**不构成任何临床诊断建议**。

### 使用限制

1. **禁止直接用于临床诊疗**  
   本项目的代码、模型及输出结果**严禁**直接用于疾病诊断、治疗决策等医疗行为。

2. **辅助参考 only**  
   模型诊断结果**仅可作为**临床医师的参考依据，**不能替代**专业医疗人员的诊断。

3. **责任承担**  
   因使用本项目代码/模型导致的任何医疗风险、法律责任，均由使用者自行承担，项目团队不承担任何责任。

### 合规要求

使用本项目时，您**必须**：

1. **遵循相关法律法规**  
   遵守《中华人民共和国个人信息保护法》、《医疗器械监督管理条例》等相关法律法规。

2. **确保数据合规性**  
   使用的医疗数据必须已获得合法授权，并完成脱敏处理（去除所有可识别个人信息 PII）。

3. **临床试验审批**  
   如需将本项目用于临床试验，必须获得相关监管机构的审批（如 NMPA 医疗器械认证）。

4. **明确标识**  
   任何基于本项目的研究成果、出版物，必须明确标识使用了本开源项目，并引用本项目。

### 完整条款

详见: [LICENSE](LICENSE) 文件（MIT License）

---

## English Version

### ⚠️ Important Notice

This project (AIMED Agent Swarm / FillingVision) is **for medical AI research and academic purposes ONLY** and **does not constitute any clinical diagnostic advice**.

### Usage Restrictions

1. **No Direct Clinical Use**  
   The code, models, and output results of this project are **strictly prohibited** from being directly used for medical actions such as disease diagnosis and treatment decisions.

2. **Reference Only**  
   Model diagnostic results can **only serve as** a reference for clinicians and **cannot replace** the diagnosis of professional medical personnel.

3. **Liability**  
   Any medical risks or legal liabilities resulting from the use of this project's code/models shall be borne by the user. The project team assumes no responsibility whatsoever.

### Compliance Requirements

When using this project, you **must**:

1. **Follow Relevant Laws**  
   Comply with the "Personal Information Protection Law of the People's Republic of China", "Medical Device Supervision and Administration Regulations", and other relevant laws and regulations.

2. **Ensure Data Compliance**  
   Medical data used must have obtained legal authorization and must be de-identified (remove all Personally Identifiable Information PII).

3. **Clinical Trial Approval**  
   If using this project for clinical trials, you must obtain approval from relevant regulatory authorities (e.g., NMPA medical device certification).

4. **Clear Identification**  
   Any research results or publications based on this project must clearly identify the use of this open-source project and cite this project.

### Full Terms

See: [LICENSE](LICENSE) file (MIT License)

---

## 引用要求 / Citation Requirements

如果您在科研出版物中使用本项目，请引用：

**中文格式**:
```
阿尔麦德 AI 团队. (2026). AIMED Agent Swarm / 充盈视界 FillingVision. 
检索自 https://github.com/aimed/aimed-agent-swarm
```

**English Format**:
```
@software{aimed_agent_swarm,
  author = {AIMED AI Team},
  title = {AIMED Agent Swarm / FillingVision},
  year = {2026},
  url = {https://github.com/aimed/aimed-agent-swarm}
}
```

---

## 联系我们 / Contact Us

如有疑问，请联系：

- **技术支持**: tech-support@aimed.com.cn
- **合规咨询**: compliance@aimed.com.cn
- **商务合作**: business@aimed.com.cn

---

**By using this project, you acknowledge that you have read, understood, and agreed to this disclaimer.**
