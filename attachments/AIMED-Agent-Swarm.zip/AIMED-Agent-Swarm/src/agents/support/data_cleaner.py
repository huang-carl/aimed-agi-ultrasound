"""
示例支撑 Agent 实现 - 数据清洗器
"""

import asyncio
from typing import Dict, Any, List
import logging
import re


class DataCleaner:
    """
    数据清洗 Agent
    
    功能:
    1. 清洗和标准化输入数据
    2. 去除噪声和异常值
    3. 数据格式转换
    4. 数据验证
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        初始化数据清洗器
        
        Args:
            config: 配置字典
        """
        self.agent_id = 'DataCleaner'
        self.config = config
        self.logger = logging.getLogger(f'aimed.agent.{self.agent_id}')
        
        # 清洗规则
        self.rules = config.get('cleaning_rules', {
            'remove_duplicates': True,
            'handle_missing': 'interpolate',  # 'drop', 'interpolate', 'fill_mean'
            'outlier_detection': 'z_score',   # 'z_score', 'iqr', 'isolation_forest'
            'normalization': 'min-max'         # 'min-max', 'z-score', 'robust'
        })
        
        self.is_running = False
        self.processed_count = 0
        
        self.logger.info(f'DataCleaner initialized with rules: {self.rules}')
    
    async def clean_data(self, data: Any, data_type: str = 'image') -> Dict[str, Any]:
        """
        清洗数据
        
        Args:
            data: 原始数据
            data_type: 数据类型 ('image', 'tabular', 'text')
            
        Returns:
            清洗后的数据和清洗报告
        """
        self.logger.info(f'Starting data cleaning for {data_type} data')
        
        cleaning_report = {
            'original_size': self._get_size(data),
            'issues_found': [],
            'actions_taken': []
        }
        
        cleaned_data = data
        
        # 根据数据类型执行不同的清洗流程
        if data_type == 'image':
            cleaned_data, report = await self._clean_image_data(cleaned_data)
            cleaning_report['actions_taken'].extend(report['actions'])
        elif data_type == 'tabular':
            cleaned_data, report = await self._clean_tabular_data(cleaned_data)
            cleaning_report['actions_taken'].extend(report['actions'])
        elif data_type == 'text':
            cleaned_data, report = await self._clean_text_data(cleaned_data)
            cleaning_report['actions_taken'].extend(report['actions'])
        else:
            raise ValueError(f'Unsupported data type: {data_type}')
        
        cleaning_report['cleaned_size'] = self._get_size(cleaned_data)
        cleaning_report['reduction_ratio'] = (
            cleaning_report['cleaned_size'] / cleaning_report['original_size'] 
            if cleaning_report['original_size'] > 0 else 1.0
        )
        
        self.processed_count += 1
        self.logger.info(f'Data cleaning completed. Reduction: '
                       f'{cleaning_report["reduction_ratio"]:.2%}')
        
        return {
            'cleaned_data': cleaned_data,
            'cleaning_report': cleaning_report
        }
    
    async def _clean_image_data(self, image_data: Any) -> tuple:
        """清洗影像数据"""
        actions = []
        
        # 示例：模拟影像清洗步骤
        await asyncio.sleep(0.5)  # 模拟处理时间
        
        # 1. 去除噪声
        actions.append('Applied Gaussian filter to remove noise')
        
        # 2. 归一化
        actions.append('Normalized pixel values to [0, 1]')
        
        # 3. .resize if needed
        actions.append('Resized image to standard dimensions')
        
        return image_data, {'actions': actions}
    
    async def _clean_tabular_data(self, tabular_data: Any) -> tuple:
        """清洗表格数据"""
        actions = []
        
        await asyncio.sleep(0.3)
        
        # 示例：模拟表格数据清洗
        actions.append('Removed duplicate rows')
        actions.append('Filled missing values')
        actions.append('Removed outliers')
        
        return tabular_data, {'actions': actions}
    
    async def _clean_text_data(self, text_data: str) -> tuple:
        """清洗文本数据"""
        actions = []
        
        await asyncio.sleep(0.1)
        
        # 示例：模拟文本清洗
        cleaned_text = text_data
        
        # 1. 去除特殊字符
        cleaned_text = re.sub(r'[^\w\s]', '', cleaned_text)
        actions.append('Removed special characters')
        
        # 2. 标准化空白字符
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
        actions.append('Normalized whitespace')
        
        return cleaned_text, {'actions': actions}
    
    def _get_size(self, data: Any) -> int:
        """获取数据大小（字节或长度）"""
        if hasattr(data, 'nbytes'):  # numpy array
            return data.nbytes
        elif isinstance(data, (list, tuple)):
            return len(data)
        elif isinstance(data, str):
            return len(data)
        elif hasattr(data, '__sizeof__'):
            return data.__sizeof__()
        else:
            return 0
    
    async def process(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        处理清洗请求
        
        Args:
            message: 包含 'data' 和 'data_type' 的消息
            
        Returns:
            清洗结果
        """
        self.logger.debug(f'Processing cleaning request')
        
        data = message.get('data')
        data_type = message.get('data_type', 'image')
        
        if data is None:
            raise ValueError('No data provided for cleaning')
        
        result = await self.clean_data(data, data_type)
        
        return {
            'status': 'success',
            'result': result,
            'agent_id': self.agent_id
        }
    
    def get_capabilities(self) -> List[str]:
        """返回能力列表"""
        return [
            'data_cleaning',
            'data_validation',
            'format_conversion',
            'noise_removal'
        ]
    
    def get_status(self) -> Dict[str, Any]:
        """获取状态"""
        return {
            'agent_id': self.agent_id,
            'is_running': self.is_running,
            'processed_count': self.processed_count,
            'rules': self.rules
        }
    
    def start(self):
        """启动 Agent"""
        self.is_running = True
        self.logger.info(f'Agent {self.agent_id} started')
    
    def stop(self):
        """停止 Agent"""
        self.is_running = False
        self.logger.info(f'Agent {self.agent_id} stopped')
