"""
双分支模型架构 - EfficientNet + Vision Transformer
用于上消化道超声影像分析

架构设计:
- 分支1: EfficientNet (局部特征提取)
- 分支2: Vision Transformer (全局特征建模)
- 特征融合: Concat + FC
- 多任务输出: 病灶检测 + 器官分割
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple


class EfficientNetBranch(nn.Module):
    """
    EfficientNet 分支 - 提取局部特征
    适用于提取纹理、边缘、病灶细节等局部特征
    """
    
    def __init__(self, model_name='efficientnet-b4', pretrained=True):
        super().__init__()
        
        # 加载预训练的 EfficientNet
        if pretrained:
            self.backbone = torch.hub.load(
                'NVIDIA/DeepLearningExamples:torchhub',
                f'nvidia_{model_name}',
                pretrained=pretrained
            )
        else:
            # 使用 timm 库
            import timm
            self.backbone = timm.create_model(
                model_name,
                pretrained=pretrained,
                num_classes=0  # 移除分类头
            )
        
        # 获取特征维度
        if model_name == 'efficientnet-b0':
            self.feature_dim = 1280
        elif model_name == 'efficientnet-b4':
            self.feature_dim = 1792
        elif model_name == 'efficientnet-b5':
            self.feature_dim = 2048
        else:
            raise ValueError(f"Unsupported model: {model_name}")
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        
        Args:
            x: 输入图像 (batch, 3, H, W)
            
        Returns:
            特征张量 (batch, feature_dim)
        """
        # 提取特征
        features = self.backbone.features(x)
        
        # 全局平均池化
        features = F.adaptive_avg_pool2d(features, (1, 1))
        features = features.view(features.size(0), -1)
        
        return features


class VisionTransformerBranch(nn.Module):
    """
    Vision Transformer 分支 - 建模全局特征
    适用于捕捉器官整体形态、位置关系等全局信息
    """
    
    def __init__(self, model_name='google/vit-base-patch16-224', pretrained=True):
        super().__init__()
        
        if pretrained:
            from transformers import ViTModel
            self.backbone = ViTModel.from_pretrained(model_name)
        else:
            from timm import create_model
            self.backbone = create_model('vit_base_patch16_224', pretrained=False)
        
        # ViT-B/16 输出维度: 768
        self.feature_dim = 768
        
        # 添加投影层，适配医疗影像
        self.proj = nn.Sequential(
            nn.Linear(self.feature_dim, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3)
        )
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        
        Args:
            x: 输入图像 (batch, 3, H, W)
            
        Returns:
            特征张量 (batch, 512)
        """
        # ViT 前向传播
        outputs = self.backbone(pixel_values=x)
        
        # 使用 [CLS] token 的特征
        cls_feature = outputs.last_hidden_state[:, 0, :]  # (batch, 768)
        
        # 投影到统一维度
        projected = self.proj(cls_feature)  # (batch, 512)
        
        return projected


class FeatureFusion(nn.Module):
    """
    特征融合模块 - 融合 EfficientNet 和 ViT 的特征
    """
    
    def __init__(self, eff_dim=1792, vit_dim=512, fusion_dim=512):
        super().__init__()
        
        # 对 EfficientNet 特征进行降维
        self.eff_proj = nn.Sequential(
            nn.Linear(eff_dim, fusion_dim),
            nn.BatchNorm1d(fusion_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3)
        )
        
        # ViT 特征已投影到 fusion_dim
        
        # 融合层
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim * 2, fusion_dim),
            nn.BatchNorm1d(fusion_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.4)
        )
        
    def forward(self, eff_feat: torch.Tensor, vit_feat: torch.Tensor) -> torch.Tensor:
        """
        融合特征
        
        Args:
            eff_feat: EfficientNet 特征 (batch, eff_dim)
            vit_feat: ViT 特征 (batch, vit_dim)
            
        Returns:
            融合特征 (batch, fusion_dim)
        """
        # 投影 EfficientNet 特征
        eff_projected = self.eff_proj(eff_feat)
        
        # 拼接特征
        concatenated = torch.cat([eff_projected, vit_feat], dim=1)
        
        # 融合
        fused = self.fusion(concatenated)
        
        return fused


class DualBranchModel(nn.Module):
    """
    双分支模型 - EfficientNet + Vision Transformer
    用于上消化道超声影像分析
    """
    
    def __init__(
        self,
        num_classes=2,  # 二分类: 正常 vs 异常
        seg_classes=1,  # 分割: 病灶区域
        eff_model='efficientnet-b4',
        vit_model='google/vit-base-patch16-224',
        pretrained=True
    ):
        super().__init__()
        
        # 分支 1: EfficientNet (局部特征)
        self.eff_branch = EfficientNetBranch(
            model_name=eff_model,
            pretrained=pretrained
        )
        
        # 分支 2: Vision Transformer (全局特征)
        self.vit_branch = VisionTransformerBranch(
            model_name=vit_model,
            pretrained=pretrained
        )
        
        # 特征融合
        self.fusion = FeatureFusion(
            eff_dim=self.eff_branch.feature_dim,
            vit_dim=512,  # ViT 投影后的维度
            fusion_dim=512
        )
        
        # 任务分支 1: 病灶检测 (分类)
        self.detection_head = nn.Sequential(
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.4),
            nn.Linear(256, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )
        
        # 任务分支 2: 器官分割
        # 注意: 分割任务通常需要解码器，这里简化为全局分割图
        self.segmentation_head = nn.Sequential(
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.4),
            nn.Linear(256, seg_classes * 224 * 224),  # 输出分割图
            nn.Sigmoid()  # 二值分割
        )
        
        # 辅助任务: 风险分层
        self.risk_head = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, 3)  # 低风险, 中风险, 高风险
        )
        
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        前向传播
        
        Args:
            x: 输入图像 (batch, 3, 224, 224)
            
        Returns:
            包含多个任务的输出字典
        """
        # 分支 1: EfficientNet
        eff_features = self.eff_branch(x)
        
        # 分支 2: Vision Transformer
        vit_features = self.vit_branch(x)
        
        # 特征融合
        fused_features = self.fusion(eff_features, vit_features)
        
        # 多任务输出
        detection_output = self.detection_head(fused_features)
        segmentation_output = self.segmentation_head(fused_features)
        risk_output = self.risk_head(fused_features)
        
        return {
            'detection': detection_output,  # (batch, num_classes)
            'segmentation': segmentation_output.view(-1, 1, 224, 224),  # (batch, 1, H, W)
            'risk': risk_output  # (batch, 3)
        }
    
    def extract_features(self, x: torch.Tensor) -> torch.Tensor:
        """
        仅提取特征（不执行任务头）
        用于特征可视化或迁移学习
        """
        eff_features = self.eff_branch(x)
        vit_features = self.vit_branch(x)
        fused_features = self.fusion(eff_features, vit_features)
        return fused_features


# ============ 模型工厂函数 ============

def create_dual_branch_model(
    num_classes=2,
    seg_classes=1,
    pretrained=True,
    device='cuda'
) -> DualBranchModel:
    """
    创建双分支模型
    
    Args:
        num_classes: 分类类别数
        seg_classes: 分割类别数
        pretrained: 是否加载预训练权重
        device: 设备 (cuda/cpu)
        
    Returns:
        初始化好的模型
    """
    model = DualBranchModel(
        num_classes=num_classes,
        seg_classes=seg_classes,
        eff_model='efficientnet-b4',
        vit_model='google/vit-base-patch16-224',
        pretrained=pretrained
    )
    
    model = model.to(device)
    
    return model


def load_model(checkpoint_path: str, device='cuda') -> DualBranchModel:
    """
    从检查点加载模型
    
    Args:
        checkpoint_path: 检查点文件路径
        device: 设备
        
    Returns:
        加载好权重的模型
    """
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    model = create_dual_branch_model(
        num_classes=checkpoint['num_classes'],
        seg_classes=checkpoint['seg_classes'],
        pretrained=False,
        device=device
    )
    
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    print(f"模型已从 {checkpoint_path} 加载")
    print(f"  训练轮次: {checkpoint['epoch']}")
    print(f"  验证准确率: {checkpoint['val_acc']:.2%}")
    
    return model


# ============ 测试代码 ============

if __name__ == '__main__':
    # 创建模型
    model = create_dual_branch_model(
        num_classes=2,
        seg_classes=1,
        pretrained=False,  # 测试时不加载预训练权重
        device='cpu'
    )
    
    # 测试前向传播
    dummy_input = torch.randn(2, 3, 224, 224)
    outputs = model(dummy_input)
    
    print("模型测试通过!")
    print(f"  输入尺寸: {dummy_input.shape}")
    print(f"  检测输出: {outputs['detection'].shape}")
    print(f"  分割输出: {outputs['segmentation'].shape}")
    print(f"  风险输出: {outputs['risk'].shape}")
    
    # 计算参数量
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    print(f"\n  总参数量: {total_params:,}")
    print(f"  可训练参数: {trainable_params:,}")
