# 充盈视界 FillingVision - AIMED AI 超声诊断系统

> **A**I **M**edical **E**chocardiography **D**iagnosis  
> **Filling Vision** - 充盈视界

上消化道 AI 超声造影智能分析平台，专注于胃、胰腺等器官的智能诊断与分析。

---

## ⚠️ 医疗免责声明

**本项目仅用于医疗 AI 科研学术研究，不构成任何临床诊断建议。**

- 模型诊断结果仅可作为临床医师参考依据
- 不能替代专业医疗人员的诊断
- 因使用本项目导致的任何医疗风险，由使用者自行承担

**详见**: [DISCLAIMER.md](DISCLAIMER.md)（完整医疗免责声明）

---

## 📋 项目概述

### 核心功能

- 🩺 **AI 诊断**: 胃、胰腺超声影像智能分析（基于 EfficientNet + ViT 双分支模型）
- 🤖 **Agent Swarm**: 21 个 Agent 协同工作
- 💻 **双部署支持**: 服务器端 GPU + AMD Ryzen AI 端侧轻量化推理
- 🌐 **多语言支持**: 中/英/法/日/韩/俄
- 🏥 **医院对接**: 与三甲医院系统集成
- 📊 **报告生成**: 自动生成诊断报告

### 项目规划

| 阶段         | 时间          | 目标                                                 |
| ------------ | ------------- | ---------------------------------------------------- |
| **现阶段**   | 2026.04-2026.12 | 完成胃部、胰腺超声影像智能分析                 |
| **短期**     | 2027          | 拓展胆管、十二指肠等上消化道器官                 |
| **长期**     | 2028+         | 对接临床超声设备，推进临床辅助诊断落地           |

### 项目信息

- **版本**: v2.0 (双部署优化版)
- **技术栈**: PyTorch + EfficientNet + Vision Transformer + LangChain + FastAPI
- **部署方式**: Docker + Kubernetes (服务器端) / AMD Ryzen AI (端侧)
- **开源协议**: MIT
- **合规状态**: 科研用途，医疗器械认证进行中

---

## 🏗️ 架构设计

### 模型架构：双分支设计

```
┌───────────────────────────────────────────────┐
│          输入：超声影像 (224x224x3)           │
└──────────────────┬────────────────────────────┘
                   │
        ┌──────────┴──────────┐
        │                     │
┌───────▼──────────┐  ┌───────▼──────────┐
│ 分支1: EfficientNet │  │ 分支2: Vision     │
│ (局部特征提取)      │  │ Transformer       │
│                    │  │ (全局特征建模)    │
└───────┬──────────┘  └───────┬──────────┘
        │                     │
        └──────────┬──────────┘
                   │
┌───────▼──────────────────────▼───────┐
│         特征融合层 (Concat + FC)         │
└───────┬──────────────────────────┬─────┘
          │                          │
    ┌─────▼─────┐          ┌─────▼─────┐
    │ 检测分支    │          │ 分割分支    │
    │ (病灶检测)  │          │ (器官分割)  │
    └─────┬─────┘          └─────┬─────┘
          │                          │
┌───────▼──────────────────────────▼───────┐
│          输出：诊断结果 + 分割掩码           │
└───────────────────────────────────────────┘
```

### Agent 分层架构

```
┌─────────────────────────────────────────────────┐
│                             用户界面层                                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                │
│  │ Web 界面  │  │ 移动端APP │  │ API 接口  │                │
│  └─────┬────┘  └─────┬────┘  └─────┬────┘                │
└────────┼───────────────┼─────────────┼──────────────────────┘
         │               │             │
         └───────────────┴─────────────┘
                          │
┌─────────────────────────▼─────────────────────────────────────┐
│                    API Gateway 层                              │
│  - 请求路由  - 认证授权  - 限流控制  - 日志审计            │
└─────────────────────────┬─────────────────────────────────────┘
                          │
┌─────────────────────────▼─────────────────────────────────────┐
│                  Agent Orchestrator                             │
│  - 工作流编排  - Agent 调度  - 任务分配  - 结果聚合         │
└─────────────────────────┬─────────────────────────────────────┘
                          │
        ┌─────────────────┴─────────────────┐
        │                                   │
┌───────▼──────────────────────┐  ┌───────▼──────────────────┐
│      诊断 Agent 层            │  │     分析 Agent 层          │
│  ┌──────────────────────┐   │  │  ┌──────────────────┐    │
│  │ StomachAnalyzer      │   │  │  │ RiskStratifier    │    │
│  ├──────────────────────┤   │  │  ├──────────────────┤    │
│  │ PancreasAnalyzer    │   │  │  │ TrendAnalyzer     │    │
│  ├──────────────────────┤   │  │  ├──────────────────┤    │
│  │ ImagePreprocessor   │   │  │  │ MultiDisciplinary │    │
│  ├──────────────────────┤   │  │  └──────────────────┘    │
│  │ FeatureExtractor    │   │  └────────────────────────────┘
│  ├──────────────────────┤   │
│  │ DiagnosisGenerator  │   │
│  ├──────────────────────┤   │
│  │ QualityChecker      │   │
│  └──────────────────────┘   │
└───────────────────────────────┘
        │
        ├─────────────────┐
        │                 │
┌───────▼──────────────┐  ┌───────▼──────────────────┐
│   支撑 Agent 层        │  │  实验室管理 Agent 层       │
│  ┌────────────────┐  │  │  ┌──────────────────┐    │
│  │ DataCleaner    │  │  │  │ AppointmentSched │    │
│  ├────────────────┤  │  │  ├──────────────────┤    │
│  │ ModelInference │  │  │  │ QualityController│    │
│  ├────────────────┤  │  │  ├──────────────────┤    │
│  │ StorageManager │  │  │  │ EquipmentMonitor │    │
│  ├────────────────┤  │  │  ├──────────────────┤    │
│  │ Logger         │  │  │  │ ReportGenerator  │    │
│  ├────────────────┤  │  │  ├──────────────────┤    │
│  │ ConfigManager  │  │  │  │ PatientFollowUp  │    │
│  ├────────────────┤  │  │  └──────────────────┘    │
│  │ NotificationSvc│  │  └────────────────────────────┘
│  └────────────────┘  │
└─────────────────────────┘
        │
        └─────────────────┐
                          │
┌─────────────────────────▼─────────────────────────────────────┐
│                    消息总线 / 数据共享层                       │
│  - Redis Pub/Sub  - 任务队列  - 事件驱动                   │
└─────────────────────────┬─────────────────────────────────────┘
                          │
┌─────────────────────────▼─────────────────────────────────────┐
│                      数据持久化层                              │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐           │
│  │ PostgreSQL │  │   Redis    │  │  Object    │           │
│  │ (关系数据)  │  │  (缓存)    │  │  Storage   │           │
│  └────────────┘  └────────────┘  └────────────┘           │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 安装与部署

AIMED 支持两种部署方式：**服务器端部署**（GPU 加速）和 **端侧部署**（AMD Ryzen AI 轻量化）。

### 方式一：服务器端部署（推荐用于数据中心）

#### 环境要求

- Python >= 3.9
- Docker >= 20.10
- PostgreSQL >= 14
- Redis >= 6.0
- NVIDIA GPU（可选，用于加速推理）

#### 安装步骤

1️⃣ **克隆项目**

```bash
git clone https://github.com/aimed/aimed-agent-swarm.git
cd aimed-agent-swarm
```

2️⃣ **配置环境变量**

```bash
cp config/env.template .env
# 编辑 .env 文件，填入你的配置
```

3️⃣ **启动服务（Docker 方式，推荐）**

```bash
docker-compose up -d
```

这会启动以下服务：

- **PostgreSQL** (端口 5432) - 数据库
- **Redis** (端口 6379) - 缓存和消息队列
- **AIMED API** (端口 8000) - API 服务
- **AIMED Web** (端口 3000) - Web 界面
- **Prometheus** (端口 9090) - 监控
- **Grafana** (端口 3001) - 可视化

4️⃣ **或本地启动（开发模式）**

```bash
# 安装依赖
pip install -r requirements.txt

# 启动开发服务器
python scripts/dev/start_dev.py
```

5️⃣ **访问系统**

- **API 文档**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **Web 界面**: http://localhost:3000
- **健康检查**: http://localhost:8000/health

---

### 方式二：端侧部署（AMD Ryzen AI）

适用于诊所、移动医疗车等边缘计算场景。

#### 硬件要求

- **CPU**: AMD Ryzen AI 处理器（如 Ryzen 7 7840HS）
- **内存**: 至少 16GB RAM
- **存储**: 至少 10GB 可用空间
- **GPU**: 不需要独立 GPU

#### 软件依赖

- **AMD Ryzen AI Software Stack**: [下载链接](https://www.amd.com/en/technologies/ryzen-ai)
- **ONNX Runtime** (支持 Vitis AI 加速)
- **PyTorch** 2.0+

#### 部署步骤

1️⃣ **安装 AMD Ryzen AI SDK**

```bash
# 按照 AMD 官方指南安装
# https://www.amd.com/en/technologies/ryzen-ai
pip install amd-ryzen-ai-sdk
```

2️⃣ **转换模型为 ONNX 格式**

```bash
python scripts/convert_to_onnx.py \
  --model_path data/models/dual_branch_v1.0.pth \
  --output_path data/models/dual_branch_v1.0.onnx
```

3️⃣ **量化与编译（Vitis AI）**

```bash
# 使用 Vitis AI 量化工具
vai_q_onnx -m data/models/dual_branch_v1.0.onnx \
  -o data/models/dual_branch_quantized.onnx
```

4️⃣ **端侧推理**

```bash
python inference/edge_inference.py \
  --model_path data/models/dual_branch_quantized.onnx \
  --image_path your_ultrasound.jpg \
  --use_ryzen_ai true
```

#### 性能对比

| 部署方式         | 推理速度   | 硬件要求       | 适用场景                 |
| ---------------- | ----------- | ---------------- | ------------------------ |
| 服务器端 (GPU)  | < 1秒/例   | 高端 GPU         | 医院中心机房             |
| 端侧 (Ryzen AI) | 2-3秒/例   | Ryzen AI PC     | 诊所、移动医疗、体检车   |

#### Docker 端侧部署

```bash
# 构建端侧部署镜像
docker build -f docker/Dockerfile.edge -t aimed-edge:latest .

# 运行端侧容器
docker run -it --device /dev/kfd --device /dev/dri \
  aimed-edge:latest
```

---

## 📁 目录结构

```
aimed-agent-swarm/
├── README.md                      # 本文件
├── DISCLAIMER.md                 # 医疗免责声明（必需阅读）
├── LICENSE                        # MIT 开源协议
├── .gitignore                     # Git 忽略规则
│
├── docs/                          # 文档目录
│   ├── architecture/              # 架构文档
│   │   ├── overview.md           # 架构总览
│   │   └── optimization-analysis.md  # 架构优化分析
│   ├── business/                  # 业务文档
│   ├── api/                       # API 文档
│   └── deployment/               # 部署文档
│       ├── server-deployment.md  # 服务器端部署
│       └── edge-deployment.md   # 端侧部署（AMD Ryzen AI）
│
├── config/                        # 配置文件
│   ├── env.template              # 环境变量模板
│   ├── system-config.json        # 系统配置
│   └── agent-config/             # Agent 配置目录
│
├── src/                           # 源代码
│   ├── agents/                   # Agent 实现
│   │   ├── diagnostic/           # 诊断 Agent
│   │   │   └── stomach_analyzer.py  # 胃分析器示例
│   │   └── support/             # 支撑 Agent
│   │       └── data_cleaner.py   # 数据清洗器示例
│   ├── core/                     # 核心框架
│   │   ├── base_agent.py        # Agent 基类
│   │   ├── message_bus.py      # 消息总线
│   │   ├── orchestrator.py     # Agent 编排器
│   │   └── model_architecture.py  # 双分支模型架构
│   └── api/                      # API 接口
│       └── main.py              # FastAPI 主应用
│
├── scripts/                       # 脚本工具
│   ├── setup/                    # 安装脚本
│   │   └── setup.py            # 自动安装向导
│   ├── dev/                     # 开发脚本
│   │   └── start_dev.py        # 开发环境启动脚本
│   └── deployment/              # 部署脚本
│       ├── convert_to_onnx.py  # 模型转换脚本
│       └── edge_inference.py   # 端侧推理脚本
│
├── inference/                     # 推理脚本
│   └── edge_inference.py       # 端侧推理
│
├── docker/                        # Docker 配置
│   ├── Dockerfile.api           # API 服务 Dockerfile
│   ├── Dockerfile.edge         # 端侧部署 Dockerfile
│   └── docker-compose.yml      # Docker Compose 配置
│
├── requirements.txt               # Python 依赖列表
├── environment.yml               # Conda 环境配置
└── QUICKSTART.md                # 快速开始指南
```

---

## 🛠️ 核心功能

### 1. 双分支模型架构

基于 **EfficientNet + Vision Transformer** 的双分支模型：

- **分支 1 (EfficientNet)**: 提取局部特征（纹理、边缘、病灶细节）
- **分支 2 (ViT)**: 建模全局特征（器官整体形态、位置关系）
- **特征融合**: Concat + FC 融合局部和全局特征
- **多任务学习**: 同时输出病灶检测和器官分割结果

### 2. Agent 编排器 (Orchestrator)

负责协调所有 Agent 的工作，管理消息总线和工作流。

```python
from src.core.orchestrator import AgentOrchestrator

orchestrator = AgentOrchestrator(config)
orchestrator.register_agent(StomachAnalyzer())
orchestrator.start()
```

### 3. 诊断工作流

```
[患者数据输入]
       ↓
[ImagePreprocessor] → 验证、清洗、标准化
       ↓
[StomachAnalyzer / PancreasAnalyzer] → AI 推理（双分支模型）
       ↓
[FeatureExtractor] → 提取关键特征
       ↓
[DiagnosisGenerator] → 生成初步诊断
       ↓
[RiskStratifier] → 风险分层
       ↓
[TrendAnalyzer] → 趋势分析（如有历史数据）
       ↓
[MultiDisciplinary] → 必要时多学科会诊
       ↓
[QualityChecker] → 质控检查
       ↓
[ReportGenerator] → 生成最终报告
       ↓
[NotificationService] → 通知相关方
       ↓
[输出] → 报告、建议、随访计划
```

### 4. 多语言支持

支持 6 种语言的报告和用户界面：

- 中文 (zh-CN)
- 英语 (en-US)
- 法语 (fr-FR)
- 日语 (ja-JP)
- 韩语 (ko-KR)
- 俄语 (ru-RU)

### 5. 海外体检项目

- 在线预约系统
- 代理佣金管理 (8-18%)
- 多语言客服
- 行程规划

---

## 📊 性能指标

| 指标             | 目标值    | 当前值   | 备注                       |
| ---------------- | --------- | -------- | -------------------------- |
| 诊断准确率       | > 95%     | 92%      | 持续改进中                 |
| 推理速度 (GPU)   | < 1秒/例  | 0.8秒    | 服务器端 GPU 加速           |
| 推理速度 (端侧) | < 3秒/例  | 2.5秒    | AMD Ryzen AI               |
| 并发用户         | 100+      | 50       | 可水平扩展                 |
| 系统可用性       | 99.9%     | 99.5%    | 高可用架构                 |
| 数据存储         | > 5 年    | -         | 可扩展存储                 |

---

## 🔒 安全与合规

### 数据安全

- ✅ 传输加密: TLS 1.3
- ✅ 存储加密: AES-256
- ✅ 访问控制: 基于角色的访问控制 (RBAC)
- ✅ 审计日志: 记录所有数据访问和操作

### 合规要求

- **个人信息保护法**: 数据收集、存储、使用合规
- **医疗器械认证**: 申请三类医疗器械认证（进行中）
- **数据本地化**: 中国公民数据存储在境内服务器
- **伦理审批**: 使用数据需获得伦理委员会审批

### 医疗免责声明

**本项目仅用于科研和学术交流，不构成临床诊断建议。**

详见: [DISCLAIMER.md](DISCLAIMER.md)

---

## 📚 文档

- [架构设计](docs/architecture/overview.md) - 完整的架构说明
- [优化分析](docs/architecture/optimization-analysis.md) - 架构优化分析
- [快速开始](QUICKSTART.md) - 10分钟快速上手
- [服务器端部署](docs/deployment/server-deployment.md) - GPU 服务器部署
- [端侧部署](docs/deployment/edge-deployment.md) - AMD Ryzen AI 部署
- [API 文档](docs/api/README.md) - API 接口说明
- [数据管理](data/README.md) - 数据准备和合规指南

---

## 🤝 贡献指南

我们欢迎任何形式的贡献！

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

### 代码规范

- 遵循 PEP 8 代码规范
- 添加类型注解（Python 3.9+）
- 编写单元测试（覆盖率 > 80%）
- 更新相关文档

---

## 📞 联系方式

- **项目官网**: https://www.aimed.com.cn
- **预约邮箱**: aimed@aius.xin
- **技术支持**: tech-support@aimed.com.cn
- **合规咨询**: compliance@aimed.com.cn
- **商务合作**: business@aimed.com.cn

### 公司主体

- 阿尔麦德智慧医疗湖州有限公司 (运营主体)
- 阿尔麦德医疗器械 (上海) 有限公司 (技术研发)
- 湖州东亚医药用品有限公司 (供应链)
- 湖州国械恒发医疗科技有限公司 (股东单位)

---

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

---

## 🙏 致谢

感谢以下开源项目：

- [LangChain](https://github.com/langchain-ai/langchain) - Agent 框架
- [FastAPI](https://fastapi.tiangolo.com/) - API 框架
- [PyTorch](https://pytorch.org/) - 深度学习框架
- [MONAI](https://monai.io/) - 医学影像 AI
- [EfficientNet-PyTorch](https://github.com/lukemelas/EfficientNet-PyTorch) - EfficientNet 实现
- [Vision Transformer](https://github.com/google-research/vision_transformer) - ViT 实现
- [OpenClaw](https://openclaw.ai/) - Agent 平台
- [AMD Ryzen AI](https://www.amd.com/en/technologies/ryzen-ai) - 端侧 AI 加速

---

## 📖 引用要求

如果您在科研出版物中使用本项目，请引用：

**中文格式**:

```
阿尔麦德 AI 团队. (2026). 充盈视界 FillingVision - AIMED AI 超声诊断系统. 
检索自 https://github.com/aimed/aimed-agent-swarm
```

**English Format**:

```
@software{aimed_filling_vision,
  author = {AIMED AI Team},
  title = {FillingVision - AIMED AI Ultrasound Diagnostic System},
  year = {2026},
  url = {https://github.com/aimed/aimed-agent-swarm}
}
```

---

**最后更新**: 2026-05-02  
**维护者**: 阿尔麦德 AI 团队  
**状态**: ✅ 双部署支持（服务器端 + AMD Ryzen AI 端侧）
