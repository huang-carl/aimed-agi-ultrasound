# 数据目录说明 / Data Directory Guide

**最后更新**: 2026-05-02  
**适用项目**: AIMED Agent Swarm / 充盈视界 FillingVision

---

## ⚠️ 重要声明

**本目录不包含任何真实患者数据、原始临床超声影像。**

本项目仅提供数据处理、模型训练与推理的**标准化代码框架**，不涉及任何医疗隐私数据。

---

## 目录结构

```
data/
├── raw/           # 原始数据（空目录，用户自行准备）
├── processed/     # 处理后的数据（空目录）
└── models/        # 训练好的模型文件（空目录，提供下载链接）
```

---

## 数据准备指南

### 1. 数据来源要求

用户需自行准备合规脱敏的超声影像数据集，并确保：

- ✅ **合法授权**: 数据已获得患者明确授权
- ✅ **脱敏处理**: 去除所有可识别个人信息 (PII)
- ✅ **合规使用**: 符合《个人信息保护法》等相关法律法规
- ✅ **伦理审批**: 如用于科研，需获得伦理委员会审批

### 2. 支持的数据格式

**图像格式**:
- JPG / JPEG
- PNG
- BMP
- TIFF

**医学影像格式**:
- DICOM (.dcm) - 医学数字成像和通信标准
- NIfTI (.nii, .nii.gz) - 神经影像信息技术倡议格式

**视频格式**:
- MP4
- AVI
- MOV

### 3. 数据目录结构（推荐）

建议在 `raw/` 目录下按以下结构组织数据：

```
raw/
├── stomach/           # 胃部超声影像
│   ├── normal/        # 正常样本
│   └── abnormal/     # 异常样本
├── pancreas/         # 胰腺超声影像
│   ├── normal/
│   └── abnormal/
└── metadata.csv      # 元数据文件（可选）
```

**metadata.csv 示例**:
```csv
patient_id,image_path,diagnosis,severity,exam_date
STOMACH_001,stomach/normal/001.jpg,normal,NA,2026-01-15
STOMACH_002,stomach/abnormal/002.jpg, gastritis,mild,2026-02-20
PANCREAS_001,pancreas/normal/001.jpg,normal,NA,2026-03-10
```

---

## 数据预处理

使用本项目提供的脚本进行预处理：

### 基础预处理

```bash
python scripts/data_preprocess.py \
  --input_dir data/raw \
  --output_dir data/processed \
  --image_size 224 224 \
  --normalize true
```

### 高级预处理（医学影像专用）

```bash
python scripts/medical_image_preprocess.py \
  --input_dir data/raw \
  --output_dir data/processed \
  --apply_denoising true \
  --apply_normalization true \
  --apply_augmentation true
```

**预处理步骤包括**:
1. **去噪**: 应用高斯滤波或中值滤波
2. **归一化**: 将像素值归一化到 [0, 1] 或 [-1, 1]
3. **尺寸标准化**: Resize 到模型输入尺寸（默认 224x224）
4. **数据增强**（训练集）: 旋转、翻转、缩放、亮度调整

---

## 预训练模型下载

由于模型文件较大（> 1GB），不存储在 Git 仓库中。

### 下载链接

| 模型 | 版本 | 大小 | 下载链接 |
|------|------|------|----------|
| 胃部模型 | v1.2 | 350 MB | [下载](https://example.com/models/stomach_v1.2.pth) |
| 胰腺模型 | v1.2 | 350 MB | [下载](https://example.com/models/pancreas_v1.2.pth) |
| 双分支模型（联合） | v1.0 | 600 MB | [下载](https://example.com/models/dual_branch_v1.0.pth) |

### 放置位置

下载后，将模型文件放置于 `data/models/` 目录：

```bash
# 创建目录
mkdir -p data/models

# 移动模型文件
mv ~/Downloads/stomach_v1.2.pth data/models/
mv ~/Downloads/pancreas_v1.2.pth data/models/
mv ~/Downloads/dual_branch_v1.0.pth data/models/
```

### 验证模型文件

```bash
# 检查文件完整性（示例）
python scripts/verify_model.py --model_path data/models/stomach_v1.2.pth
```

---

## 数据隐私保护

### 脱敏处理要求

在对数据进行处理前，必须确保：

1. **移除所有 PII**:
   - 患者姓名
   - 身份证号
   - 医保卡号
   - 电话号码
   - 地址信息

2. **匿名化**:
   - 使用随机 ID 替代患者 ID
   - 移除日期中的年份（仅保留月日）
   - 移除医院名称、科室名称

3. **数据加密**（推荐）:
   - 存储时加密敏感数据
   - 传输时使用 TLS 1.3 加密

### 数据处理脚本示例

```python
"""
数据脱敏处理示例
"""
import pandas as pd
import hashlib

def deidentify_metadata(csv_path, output_path):
    """对元数据 CSV 进行脱敏处理"""
    df = pd.read_csv(csv_path)
    
    # 1. 哈希化患者 ID
    df['patient_id'] = df['patient_id'].apply(
        lambda x: hashlib.sha256(x.encode()).hexdigest()[:16]
    )
    
    # 2. 移除敏感列（如果存在）
    sensitive_columns = ['name', 'phone', 'id_card', 'address']
    for col in sensitive_columns:
        if col in df.columns:
            df = df.drop(columns=[col])
    
    # 3. 模糊化日期
    df['exam_date'] = pd.to_datetime(df['exam_date']).dt.strftime('%m-%d')
    
    # 保存脱敏后的数据
    df.to_csv(output_path, index=False)
    print(f"脱敏完成，已保存到: {output_path}")

if __name__ == '__main__':
    deidentify_metadata('data/raw/metadata.csv', 'data/raw/metadata_deidentified.csv')
```

---

## 数据使用合规自查清单

在使用数据前，请确认：

- [ ] 已获得患者书面授权
- [ ] 数据已完成脱敏处理
- [ ] 数据使用符合《个人信息保护法》
- [ ] 如用于科研，已获得伦理委员会审批
- [ ] 数据存储符合安全标准（加密、访问控制）
- [ ] 数据仅用于本项目指定的用途
- [ ] 不将数据用于商业目的（除非已获得额外授权）

---

## 常见问题

### Q1: 我可以使用医院的真实患者数据吗？

**A**: 可以，但必须满足以下条件：
1. 获得患者明确授权
2. 完成脱敏处理
3. 获得伦理委员会审批
4. 符合《个人信息保护法》要求

### Q2: 我可以分享处理后的数据吗？

**A**: 不建议。即使已完成脱敏处理，仍建议：
1. 仅分享数据使用协议
2. 不分享原始数据或处理后的数据
3. 如必须分享，签署严格的数据使用协议（DUA）

### Q3: 模型训练完成后，如何删除数据？

**A**: 使用安全删除工具：

```bash
# macOS / Linux
srm -rf data/raw/*
srm -rf data/processed/*

# 或使用 shred
find data/raw -type f -exec shred -vfz -n 3 {} \;
```

---

## 联系我们

如有数据合规性疑问，请联系：

- **合规咨询**: compliance@aimed.com.cn
- **技术支持**: tech-support@aimed.com.cn

---

**最后更新**: 2026-05-02  
**维护者**: 阿尔麦德 AI 团队
