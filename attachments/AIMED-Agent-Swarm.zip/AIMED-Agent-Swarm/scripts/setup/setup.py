#!/usr/bin/env python3
"""
AIMED Agent Swarm - 安装设置脚本
自动完成环境检查、依赖安装、配置初始化
"""

import os
import sys
import json
import subprocess
import logging
from pathlib import Path
from typing import List, Dict, Any

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('aimed-setup')

class Color:
    """终端颜色"""
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    END = '\033[0m'

def print_success(msg: str):
    print(f"{Color.GREEN}✓ {msg}{Color.END}")

def print_warning(msg: str):
    print(f"{Color.YELLOW}⚠ {msg}{Color.END}")

def print_error(msg: str):
    print(f"{Color.RED}✗ {msg}{Color.END}")

def print_info(msg: str):
    print(f"{Color.BLUE}ℹ {msg}{Color.END}")


class AIMEDSetup:
    """AIMED Agent Swarm 安装器"""
    
    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.config_dir = self.project_root / 'config'
        self.data_dir = self.project_root / 'data'
        self.logs_dir = self.project_root / '.logs'
        
    def check_python_version(self) -> bool:
        """检查 Python 版本"""
        print_info("检查 Python 版本...")
        version = sys.version_info
        if version.major < 3 or (version.major == 3 and version.minor < 9):
            print_error(f"Python 版本过低: {version.major}.{version.minor}")
            print_warning("需要 Python >= 3.9")
            return False
        print_success(f"Python 版本检查通过: {version.major}.{version.minor}")
        return True
    
    def check_docker(self) -> bool:
        """检查 Docker 是否安装"""
        print_info("检查 Docker...")
        try:
            result = subprocess.run(['docker', '--version'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print_success(f"Docker 已安装: {result.stdout.strip()}")
                return True
        except FileNotFoundError:
            pass
        
        print_warning("Docker 未安装")
        print_info("请访问 https://docs.docker.com/get-docker/ 安装 Docker")
        return False
    
    def create_directories(self):
        """创建必要的目录"""
        print_info("创建项目目录...")
        
        directories = [
            self.data_dir / 'raw',
            self.data_dir / 'processed',
            self.data_dir / 'models',
            self.logs_dir,
            self.project_root / 'reports' / 'diagnostic-reports',
            self.project_root / 'reports' / 'analysis-reports'
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            print_success(f"创建目录: {directory.relative_to(self.project_root)}")
    
    def create_env_file(self):
        """创建 .env 配置文件"""
        print_info("创建环境配置文件...")
        
        env_template = self.config_dir / 'env.template'
        env_file = self.project_root / '.env'
        
        if env_file.exists():
            print_warning(f"{env_file} 已存在，跳过")
            return
        
        if not env_template.exists():
            print_error(f"模板文件不存在: {env_template}")
            return
        
        # 读取模板并生成 .env
        with open(env_template, 'r') as f:
            content = f.read()
        
        # 生成随机密钥
        import secrets
        secret_key = secrets.token_hex(32)
        
        # 替换占位符
        content = content.replace(
            'your_secure_password_here',
            secrets.token_urlsafe(16)
        )
        content = content.replace(
            'your_secret_key_here_change_in_production',
            secret_key
        )
        content = content.replace(
            'your_smtp_password_here',
            'CHANGE_ME'
        )
        
        with open(env_file, 'w') as f:
            f.write(content)
        
        print_success(f"已创建 {env_file}")
        print_warning("请编辑 .env 文件，填入实际的配置值")
    
    def install_python_dependencies(self):
        """安装 Python 依赖"""
        print_info("安装 Python 依赖...")
        
        requirements_file = self.project_root / 'requirements.txt'
        
        if not requirements_file.exists():
            print_error(f"requirements.txt 不存在: {requirements_file}")
            return False
        
        try:
            subprocess.run(
                [sys.executable, '-m', 'pip', 'install', '-r', str(requirements_file)],
                check=True
            )
            print_success("Python 依赖安装完成")
            return True
        except subprocess.CalledProcessError as e:
            print_error(f"依赖安装失败: {e}")
            return False
    
    def initialize_config(self):
        """初始化配置文件"""
        print_info("初始化配置文件...")
        
        config_file = self.config_dir / 'system-config.json'
        
        if not config_file.exists():
            print_error(f"配置文件不存在: {config_file}")
            return False
        
        with open(config_file, 'r') as f:
            config = json.load(f)
        
        # 更新配置（根据实际环境调整）
        config['system']['environment'] = 'development'
        config['database']['host'] = 'localhost'
        config['redis']['host'] = 'localhost'
        
        with open(config_file, 'w') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        print_success("配置文件初始化完成")
        return True
    
    def create_sample_data(self):
        """创建示例数据"""
        print_info("创建示例数据...")
        
        sample_dir = self.data_dir / 'raw' / 'samples'
        sample_dir.mkdir(parents=True, exist_ok=True)
        
        # 创建示例配置文件
        sample_config = {
            'sample_image': 'sample_stomach.jpg',
            'sample_metadata': {
                'patient_id': 'SAMPLE001',
                'age': 45,
                'gender': 'M',
                'exam_date': '2026-05-02'
            }
        }
        
        with open(sample_dir / 'sample_config.json', 'w') as f:
            json.dump(sample_config, f, indent=2)
        
        print_success("示例数据创建完成")
    
    def run(self):
        """执行完整安装流程"""
        print("\n" + "="*60)
        print("  AIMED Agent Swarm - 安装向导")
        print("="*60 + "\n")
        
        # 1. 检查环境
        print("\n[1/7] 环境检查")
        if not self.check_python_version():
            return False
        docker_available = self.check_docker()
        
        # 2. 创建目录
        print("\n[2/7] 创建目录结构")
        self.create_directories()
        
        # 3. 创建配置文件
        print("\n[3/7] 配置文件生成")
        self.create_env_file()
        
        # 4. 初始化配置
        print("\n[4/7] 初始化系统配置")
        self.initialize_config()
        
        # 5. 安装依赖
        print("\n[5/7] 安装依赖")
        if not self.install_python_dependencies():
            print_warning("依赖安装失败，请手动执行: pip install -r requirements.txt")
        
        # 6. 创建示例数据
        print("\n[6/7] 创建示例数据")
        self.create_sample_data()
        
        # 7. 完成
        print("\n[7/7] 安装完成")
        print("\n" + "-"*60)
        print_success("AIMED Agent Swarm 安装完成！")
        print("\n下一步:")
        print("  1. 编辑 .env 文件，填入实际配置")
        print("  2. 启动服务: python scripts/dev/start_dev.py")
        if not docker_available:
            print("  3. 安装 Docker 用于容器化部署")
        print("\n访问地址:")
        print("  - API 文档: http://localhost:8000/docs")
        print("  - Web 界面: http://localhost:3000")
        print("-"*60 + "\n")
        
        return True


if __name__ == '__main__':
    setup = AIMEDSetup()
    success = setup.run()
    sys.exit(0 if success else 1)
