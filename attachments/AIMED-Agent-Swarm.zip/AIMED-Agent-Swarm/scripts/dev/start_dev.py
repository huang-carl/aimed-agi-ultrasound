#!/usr/bin/env python3
"""
开发环境启动脚本
快速启动 AIMED Agent Swarm 进行开发测试
"""

import os
import sys
import subprocess
from pathlib import Path

# 项目根目录
PROJECT_ROOT = Path(__file__).parent.parent.parent

# 检查 .env 文件
env_file = PROJECT_ROOT / '.env'
if not env_file.exists():
    print("⚠️  .env 文件不存在，正在创建...")
    setup_script = PROJECT_ROOT / 'scripts' / 'setup' / 'setup.py'
    subprocess.run([sys.executable, str(setup_script)])

# 设置 PYTHONPATH
os.environ['PYTHONPATH'] = str(PROJECT_ROOT / 'src')

# 启动 API 服务
print("🚀 启动 AIMED Agent Swarm API 服务...")
print(f"   API 文档: http://localhost:8000/docs")
print(f"   ReDoc: http://localhost:8000/redoc")
print("\n按 Ctrl+C 停止服务\n")

try:
    subprocess.run([
        sys.executable, '-m', 'uvicorn',
        'src.api.main:app',
        '--host', '0.0.0.0',
        '--port', '8000',
        '--reload'
    ], cwd=PROJECT_ROOT)
except KeyboardInterrupt:
    print("\n\n✅ 服务已停止")
