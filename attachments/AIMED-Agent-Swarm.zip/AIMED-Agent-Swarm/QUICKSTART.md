# AIMED Agent Swarm - 快速开始指南

本指南将帮助你在 10 分钟内启动 AIMED Agent Swarm 系统。

---

## 前置要求

- Python >= 3.9
- pip (Python 包管理器)
- Git
- (可选) Docker & Docker Compose

---

## 方式一：本地快速启动

### 1. 运行安装脚本

```bash
cd /Users/aimed/Desktop/AIMED-Agent-Swarm
python3 scripts/setup/setup.py
```

安装脚本会自动：
- ✅ 检查 Python 版本
- ✅ 创建必要的目录
- ✅ 生成 `.env` 配置文件
- ✅ 安装 Python 依赖
- ✅ 初始化系统配置

### 2. 配置环境变量

编辑 `.env` 文件，至少修改以下配置：

```bash
# 修改数据库密码
POSTGRES_PASSWORD=your_secure_password

# 修改 Redis 密码
REDIS_PASSWORD=your_redis_password

# 修改密钥（必须修改！）
SECRET_KEY=your_very_long_secret_key_here
```

### 3. 启动数据库服务

如果你已安装 PostgreSQL 和 Redis：

```bash
# macOS (使用 Homebrew)
brew services start postgresql
brew services start redis

# Ubuntu/Debian
sudo systemctl start postgresql
sudo systemctl start redis-server
```

或者，如果你安装了 Docker，可以直接运行：

```bash
docker-compose up -d postgres redis
```

### 4. 启动 API 服务

```bash
cd /Users/aimed/Desktop/AIMED-Agent-Swarm
python3 -m uvicorn src.api.main:app --reload --host 0.0.0.0 --port 8000
```

### 5. 访问系统

打开浏览器访问：
- **API 文档**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **健康检查**: http://localhost:8000/health

---

## 方式二：Docker 一键启动

### 1. 配置环境变量

```bash
cp config/env.template .env
# 编辑 .env 文件
```

### 2. 启动所有服务

```bash
docker-compose up -d
```

这会启动以下服务：
- PostgreSQL (端口 5432)
- Redis (端口 6379)
- AIMED API (端口 8000)
- AIMED Web (端口 3000)
- Prometheus (端口 9090)
- Grafana (端口 3001)

### 3. 查看日志

```bash
# 查看 API 日志
docker-compose logs -f api

# 查看所有服务日志
docker-compose logs -f
```

### 4. 停止服务

```bash
docker-compose down
```

---

## 验证安装

### 1. 健康检查

```bash
curl http://localhost:8000/health
```

预期响应：
```json
{
  "status": "healthy",
  "service": "AIMED Agent Swarm",
  "version": "2.0.0",
  "timestamp": "2026-05-02T..."
}
```

### 2. 查看 API 文档

访问 http://localhost:8000/docs，你应该能看到交互式 API 文档。

### 3. 测试诊断接口

在 API 文档页面，找到 `/diagnose/stomach` 接口，点击 "Try it out"，然后执行测试。

---

## 下一步

1. **阅读架构文档**: `docs/architecture/overview.md`
2. **配置 Agent**: `config/agent-config/`
3. **运行测试**: `pytest tests/`
4. **查看示例代码**: `src/agents/diagnostic/stomach_analyzer.py`

---

## 常见问题

### Q1: Python 版本不对怎么办？

**A**: 使用 pyenv 安装多个 Python 版本：

```bash
# 安装 pyenv
curl https://pyenv.run | bash

# 安装 Python 3.11
pyenv install 3.11.0
pyenv local 3.11.0
```

### Q2: 端口被占用怎么办？

**A**: 修改 `.env` 文件中的端口配置：

```bash
API_PORT=8001  # 改为其他端口
```

### Q3: 数据库连接失败？

**A**: 检查以下几点：
1. PostgreSQL 是否正在运行？
2. 数据库用户和密码是否正确？
3. 防火墙是否阻止了连接？

### Q4: 依赖安装失败？

**A**: 尝试使用国内镜像源：

```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

---

## 获取帮助

- **项目文档**: `docs/` 目录
- **Issue 追踪**: https://github.com/aimed/aimed-agent-swarm/issues
- **技术支持**: tech-support@aimed.com.cn
- **商务合作**: business@aimed.com.cn

---

**最后更新**: 2026-05-02
